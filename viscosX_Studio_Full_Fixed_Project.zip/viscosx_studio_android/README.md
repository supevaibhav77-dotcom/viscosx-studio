# viscosX Studio — Android starter app

A native Android / Jetpack Compose starter project for the viscosX YouTube channel,
focused on Phantom Blade Zero Shorts.

## Included now
- Dark creator dashboard and bottom navigation
- Channel profile field
- Shorts manager screen (clearly marked placeholder data)
- Zero-views diagnostic checklist
- Local content idea board (add and delete ideas)
- Analytics and management feature layout
- AI Growth Engine with both modes: an automatic first-pass review after successful uploads and a manual Analyze Short screen
- Rule-based title, zero-view, engagement and retention coaching from entered metrics

## YouTube integration status and limitations
The project includes OAuth scaffolding, basic channel-stat fetching, and resumable video upload code. Detailed YouTube Analytics reports, a synced Shorts library, video editing, and comment management are not implemented yet. The Growth Engine currently provides rule-based coaching: it runs automatically after a successful upload using the title, and manual analysis accepts metrics entered from YouTube Studio. It does not yet automatically fetch each Short’s analytics or use a hosted generative-AI model.

To enable those capabilities, a developer must configure:
1. A Google Cloud project.
2. YouTube Data API v3 and YouTube Analytics API.
3. OAuth consent screen and Android OAuth client for the app's package name.
4. A secure OAuth authorization flow and token handling.
5. API calls for channel/video statistics, analytics reports, video uploads,
   playlist/video management, and comment threads/replies.

Relevant API documentation:
- https://developers.google.com/youtube/v3
- https://developers.google.com/youtube/analytics
- https://developers.google.com/identity

YouTube API scopes should be requested only when needed. Uploads and public-facing
actions should require an explicit confirmation in the app. Never put a client
secret in the Android source code.

## Build and install
1. Install Android Studio (current stable).
2. Open this project folder.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press Run, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Copy the generated APK from `app/build/outputs/apk/debug/app-debug.apk` to your Android phone and install it. For direct installation, allow your file manager/browser to install unknown apps when Android prompts you.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01,
compileSdk 35, and minSdk 26.

## Important build note
This source archive is not itself an APK. It must be built in Android Studio. Configure the Google Cloud OAuth Android client for package `com.viscosx.studio` and the signing certificate SHA-1 before connecting your real YouTube account. The current workspace used to prepare this archive did not contain Gradle or the Android SDK, so no installable APK could be compiled or tested here.
