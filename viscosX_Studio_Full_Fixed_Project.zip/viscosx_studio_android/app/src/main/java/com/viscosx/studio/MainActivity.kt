package com.viscosx.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.common.api.Scope

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D23)
private val Muted = Color(0xFF9DA3AE)
private val Red = Color(0xFFFF3434)
private val Green = Color(0xFF39C98A)

class MainActivity : ComponentActivity() {
    private var authCallback: ((Result<String>) -> Unit)? = null
    private val requestCode = 8107
    private val youtubeScope = "https://www.googleapis.com/auth/youtube"
    private val analyticsScope = "https://www.googleapis.com/auth/yt-analytics.readonly"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViscosXApp(this) }
    }

    fun connectYouTube(callback: (Result<String>) -> Unit) {
        authCallback = callback
        try {
            val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(Scope(youtubeScope), Scope(analyticsScope))
                .build()
            val client = GoogleSignIn.getClient(this, options)
            @Suppress("DEPRECATION")
            startActivityForResult(client.signInIntent, requestCode)
        } catch (e: Exception) {
            finishAuthorization(Result.failure(e))
        }
    }

    @Deprecated("Google Sign-In returns its result through this compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != this.requestCode) return
        if (resultCode != RESULT_OK || data == null) {
            finishAuthorization(Result.failure(IllegalStateException("Google sign-in was cancelled.")))
            return
        }

        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(data)
                .getResult(ApiException::class.java)
            val googleAccount = account.account
                ?: throw IllegalStateException("Google did not return an account.")
            Thread {
                try {
                    val scopes = "oauth2:$youtubeScope $analyticsScope"
                    val accessToken = GoogleAuthUtil.getToken(applicationContext, googleAccount, scopes)
                    if (accessToken.isBlank()) {
                        finishAuthorization(Result.failure(IllegalStateException("Google returned an empty access token.")))
                    } else {
                        finishAuthorization(Result.success(accessToken))
                    }
                } catch (e: Exception) {
                    finishAuthorization(Result.failure(e))
                }
            }.start()
        } catch (e: Exception) {
            finishAuthorization(Result.failure(e))
        }
    }

    private fun finishAuthorization(result: Result<String>) {
        runOnUiThread {
            authCallback?.invoke(result)
            authCallback = null
        }
    }
}

@Composable
fun ViscosXApp(activity: MainActivity) {
    var tab by remember { mutableStateOf("Home") }
    var channel by remember { mutableStateOf("viscosX") }
    var token by remember { mutableStateOf<String?>(null) }
    var channelStats by remember { mutableStateOf<YouTubeApi.ChannelStats?>(null) }
    var connectionMessage by remember { mutableStateOf("Not connected") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var newIdea by remember { mutableStateOf("") }
    var ideas by remember { mutableStateOf(listOf("Phantom Blade Zero: 3 combat details you missed", "The cleanest boss fight combo", "Before you fight this boss, know this")) }
    var checked by remember { mutableStateOf(setOf<Int>()) }
    var growthReport by remember { mutableStateOf("Upload a Short or enter its metrics, then tap Analyze Short.") }
    var growthTitle by remember { mutableStateOf("Phantom Blade Zero #Shorts") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val names = listOf("Home", "Shorts", "Growth AI", "Diagnose", "Planner", "Settings")
                    val icons = listOf(Icons.Default.Home, Icons.Default.PlayCircle, Icons.Default.AutoAwesome, Icons.Default.Search, Icons.Default.CalendarMonth, Icons.Default.Settings)
                    names.forEachIndexed { i, name ->
                        NavigationBarItem(
                            selected = tab == name, onClick = { tab = name },
                            icon = { Icon(icons[i], contentDescription = name) },
                            label = { Text(name, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, indicatorColor = Color(0xFF382126), unselectedIconColor = Muted, unselectedTextColor = Muted)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "Home" -> HomeScreen(
                        channel, channelStats, connectionMessage, loading, error,
                        onConnect = {
                            loading = true; error = null
                            activity.connectYouTube { result ->
                                result.onSuccess { access ->
                                    token = access
                                    connectionMessage = "Connected to Google authorization"
                                    YouTubeApi.loadChannel(access) { channelResult ->
                                        activity.runOnUiThread {
                                            channelResult.onSuccess { stats ->
                                                channelStats = stats
                                                channel = stats.title
                                                connectionMessage = "Connected to ${stats.title}"
                                                error = null
                                            }.onFailure { error = it.message ?: "Could not load channel" }
                                            loading = false
                                        }
                                    }
                                }.onFailure {
                                    loading = false
                                    error = it.message ?: "Connection failed"
                                }
                            }
                        }
                    )
                    "Shorts" -> ShortsScreen(token, onAutoAnalyze = { uploadedTitle ->
                        growthTitle = uploadedTitle
                        growthReport = buildGrowthReport(uploadedTitle, 0, 0, 0, 0)
                    })
                    "Growth AI" -> GrowthAiScreen(growthTitle, { growthTitle = it }, growthReport, { growthReport = it })
                    "Diagnose" -> DiagnoseScreen(checked, { checked = it })
                    "Planner" -> PlannerScreen(newIdea, { newIdea = it }, ideas, { ideas = it })
                    "Settings" -> SettingsScreen(channel, { channel = it }, connectionMessage)
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(4.dp)); Text(subtitle, fontSize = 13.sp, color = Muted)
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun HomeScreen(
    channel: String, stats: YouTubeApi.ChannelStats?, status: String, loading: Boolean,
    error: String?, onConnect: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Red, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
                Spacer(Modifier.width(11.dp))
                Column { Text("viscosX Studio", fontWeight = FontWeight.Bold, fontSize = 19.sp); Text("Your YouTube command center", color = Muted, fontSize = 12.sp) }
                Spacer(Modifier.weight(1f))
                Surface(color = if (stats != null) Color(0xFF17382D) else Color(0xFF382126), shape = RoundedCornerShape(30.dp)) {
                    Text(if (stats != null) "CONNECTED" else "NOT CONNECTED", color = if (stats != null) Green else Red, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
                }
            }
        }
        item { Text("Welcome back, $channel", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            CardBox {
                Text("YouTube account", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(status, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = onConnect, enabled = !loading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.Link, null)
                    Spacer(Modifier.width(7.dp)); Text(if (loading) "Connecting..." else "Connect YouTube with Google")
                }
                if (error != null) { Spacer(Modifier.height(6.dp)); Text(error, color = Color(0xFFFF8A80), fontSize = 11.sp) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Views", stats?.views?.toLongOrNull()?.let { "%,d".format(it) } ?: "—", "Channel lifetime", Modifier.weight(1f))
                MetricCard("Subscribers", stats?.subscribers?.toLongOrNull()?.let { "%,d".format(it) } ?: stats?.subscribers ?: "—", "Current count", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Videos", stats?.videos ?: "—", "Published", Modifier.weight(1f))
                MetricCard("Watch time", "Analytics API", "Next integration step", Modifier.weight(1f))
            }
        }
        item {
            CardBox {
                Text("Your growth mission", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                MissionRow("Find why a Short has zero views", "Diagnose")
                MissionRow("Improve the first 2 seconds", "Hook")
                MissionRow("Compare recent Shorts", "Analytics")
            }
        }
        item { Text("Only channel statistics are fetched in this build. The Shorts uploader is available in the Shorts tab after authorization.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
fun MetricCard(label: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}
@Composable
fun MissionRow(title: String, tag: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.CheckCircleOutline, null, tint = Green, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(9.dp)); Text(title, Modifier.weight(1f), fontSize = 13.sp); Text(tag, color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun ShortsScreen(token: String?, onAutoAnalyze: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("Phantom Blade Zero #Shorts") }
    var description by remember { mutableStateOf("Phantom Blade Zero gameplay. #PhantomBladeZero #Shorts") }
    var privacy by remember { mutableStateOf("private") }
    var uploading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { pickedUri = it; result = null }

    Column(Modifier.fillMaxSize()) {
        Header("Shorts manager", "Select and upload a Short to your channel")
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CardBox {
                    Text("Upload a Short", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Choose a vertical video from your phone. YouTube determines Shorts eligibility based on video format and current platform rules.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(7.dp)); Text(if (pickedUri == null) "Choose video" else "Choose a different video")
                    }
                    if (pickedUri != null) Text("Video selected: ${pickedUri.toString().takeLast(32)}", color = Green, fontSize = 10.sp)
                    Spacer(Modifier.height(9.dp))
                    OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Title") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(description, { description = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Description") }, minLines = 3)
                    Spacer(Modifier.height(8.dp))
                    Text("Visibility", color = Muted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        listOf("private", "unlisted", "public").forEach { choice ->
                            Row(Modifier.weight(1f).clickable { privacy = choice }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = privacy == choice, onClick = { privacy = choice }, colors = RadioButtonDefaults.colors(selectedColor = Red))
                                Text(choice.replaceFirstChar { it.uppercase() }, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Button(
                        onClick = {
                            val currentToken = token
                            val currentUri = pickedUri
                            if (currentToken == null) result = "Connect your YouTube account on Home first."
                            else if (currentUri == null) result = "Choose a video first."
                            else if (title.isBlank()) result = "Enter a title."
                            else {
                                uploading = true; result = "Starting upload..."
                                YouTubeApi.uploadVideo(context, currentToken, currentUri, title.trim(), description, privacy) { outcome ->
                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                        uploading = false
                                        result = outcome.fold({ message -> onAutoAnalyze(title.trim()); message }, { "Upload failed: ${it.message}" })
                                    }
                                }
                            }
                        },
                        enabled = !uploading,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                    ) {
                        if (uploading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.CloudUpload, null)
                        Spacer(Modifier.width(7.dp)); Text(if (uploading) "Uploading..." else "Upload to YouTube")
                    }
                    if (result != null) { Spacer(Modifier.height(8.dp)); Text(result!!, color = if (result!!.startsWith("Upload complete")) Green else Muted, fontSize = 11.sp) }
                    Text("Uploads are private by default. Review visibility and confirm before tapping Upload.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

private fun buildGrowthReport(title: String, views: Int, likes: Int, comments: Int, retention: Int): String {
    val tips = mutableListOf<String>()
    if (title.length < 25) tips.add("Try a clearer, more specific title that tells viewers what exciting moment they will see.")
    if (!title.contains("Phantom Blade", ignoreCase = true)) tips.add("Include the game name naturally so the right gaming audience can identify the Short.")
    if (views == 0) tips.add("Zero views: confirm visibility is Public, check restrictions in YouTube Studio, and inspect whether the Short was shown in the Shorts feed.")
    else if (views < 100) tips.add("Early reach is small. Check shown-in-feed and viewed-vs-swiped-away before changing the video.")
    if (views > 0 && likes * 100 / views < 3) tips.add("Like rate is below 3% in the entered sample. Test a stronger payoff and a simple question that invites genuine reactions.")
    if (comments == 0 && views >= 100) tips.add("Try a specific, easy-to-answer question related to the gameplay to invite comments.")
    if (retention in 1..100 && retention < 70) tips.add("Entered retention is below 70%. Tighten the opening, remove slow setup, and show the strongest moment earlier.")
    if (tips.isEmpty()) tips.add("Good starting signals. Compare this Short with your channel's own recent Shorts and keep testing one change at a time.")
    return "GROWTH REVIEW\nTitle: $title\nEntered metrics: $views views • $likes likes • $comments comments • $retention% retention\n\nNEXT ACTIONS\n" + tips.mapIndexed { i, tip -> "${i + 1}. $tip" }.joinToString("\n") + "\n\nNote: These are rule-based coaching suggestions, not a prediction or guarantee of views. YouTube Studio metrics are needed for a true performance review."
}

@Composable
fun GrowthAiScreen(titleValue: String, onTitle: (String) -> Unit, report: String, onReport: (String) -> Unit) {
    var views by remember { mutableStateOf("0") }
    var likes by remember { mutableStateOf("0") }
    var comments by remember { mutableStateOf("0") }
    var retention by remember { mutableStateOf("0") }
    Column(Modifier.fillMaxSize()) {
        Header("AI Growth Engine", "Automatic after upload + manual analysis")
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Red)
                        Spacer(Modifier.width(8.dp)); Text("Both modes enabled", fontWeight = FontWeight.Bold)
                    }
                    Text("Automatic: creates a first-pass review after a successful upload. Manual: enter YouTube Studio metrics below and analyze any Short.", color = Muted, fontSize = 12.sp)
                }
            }
            item {
                CardBox {
                    Text("Analyze a Short", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(titleValue, onTitle, modifier = Modifier.fillMaxWidth(), label = { Text("Short title") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(views, { views = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("Views") }, singleLine = true)
                        OutlinedTextField(likes, { likes = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("Likes") }, singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(comments, { comments = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("Comments") }, singleLine = true)
                        OutlinedTextField(retention, { retention = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), label = { Text("Retention %") }, singleLine = true)
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onReport(buildGrowthReport(titleValue, views.toIntOrNull() ?: 0, likes.toIntOrNull() ?: 0, comments.toIntOrNull() ?: 0, retention.toIntOrNull() ?: 0)) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                        Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(7.dp)); Text("Analyze Short")
                    }
                }
            }
            item {
                CardBox {
                    Text("Your growth report", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(report, color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
        }
    }
}

@Composable
fun DiagnoseScreen(checked: Set<Int>, onChecked: (Set<Int>) -> Unit) {
    val checks = listOf(
        "Confirm the Short is Public, not Private or Unlisted",
        "Check YouTube Studio for copyright or restriction notices",
        "Check whether the video appears in the Shorts tab",
        "Review shown-in-feed and viewed-vs-swiped-away metrics",
        "Check audience retention and the opening 1–2 seconds",
        "Compare title, topic and upload timing with similar Shorts"
    )
    Column(Modifier.fillMaxSize()) {
        Header("Zero Views Detective", "A practical checklist for Shorts with no views")
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CardBox {
                    Text("Important", fontWeight = FontWeight.Bold, color = Red)
                    Text("Zero views alone does not prove a shadowban. Check visibility, restrictions and Shorts-feed distribution before changing or reuploading.", color = Muted, fontSize = 12.sp)
                }
            }
            item {
                CardBox {
                    Text("Diagnostic checklist", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    checks.forEachIndexed { i, label ->
                        Row(Modifier.fillMaxWidth().clickable { onChecked(if (i in checked) checked - i else checked + i) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(i in checked, { onChecked(if (it) checked + i else checked - i) }, colors = CheckboxDefaults.colors(checkedColor = Green))
                            Spacer(Modifier.width(5.dp)); Text(label, fontSize = 12.sp, color = if (i in checked) Muted else Color.White)
                        }
                    }
                    Text("${checked.size}/${checks.size} checks completed", color = Green, fontSize = 11.sp)
                }
            }
            item {
                CardBox {
                    Text("Metrics to analyze", fontWeight = FontWeight.Bold)
                    Text("Shown in feed • Viewed vs swiped away • Average view duration • Average percentage viewed • Likes • Comments • Traffic sources", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun PlannerScreen(value: String, onValue: (String) -> Unit, ideas: List<String>, onIdeas: (List<String>) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("Content planner", "Build your next Phantom Blade Zero Short")
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CardBox {
                    Text("Add a video idea", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Enter your next Short idea...") }, minLines = 2)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { if (value.isNotBlank()) { onIdeas(listOf(value.trim()) + ideas); onValue("") } }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Save idea")
                    }
                }
            }
            item { Text("Your idea board", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            items(ideas) { idea ->
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lightbulb, null, tint = Red); Spacer(Modifier.width(10.dp))
                        Text(idea, Modifier.weight(1f), fontSize = 13.sp)
                        IconButton(onClick = { onIdeas(ideas - idea) }) { Icon(Icons.Default.DeleteOutline, null, tint = Muted) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(channel: String, onChannel: (String) -> Unit, status: String) {
    Column(Modifier.fillMaxSize()) {
        Header("Settings", "Set up your creator workspace")
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            CardBox {
                Text("Channel profile", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(10.dp)); Text("Channel name", color = Muted, fontSize = 12.sp)
                OutlinedTextField(channel, onChannel, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp)); Text("Channel handle: @viscosx-p6o", color = Muted, fontSize = 12.sp)
                Text("Content focus: Phantom Blade Zero Shorts", color = Muted, fontSize = 12.sp)
            }
            CardBox {
                Text("YouTube authorization", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp)); Text(status, color = Muted, fontSize = 12.sp)
                Text("Connect from Home using Google's official account authorization. This app requests YouTube channel management and read-only Analytics access.", color = Muted, fontSize = 11.sp)
            }
            CardBox {
                Text("Permissions planned", fontWeight = FontWeight.Bold)
                Text("• Read channel and video statistics\n• Upload videos with your chosen visibility\n• Manage videos and comments in future screens\n• Read YouTube Analytics reports", color = Muted, fontSize = 12.sp)
            }
        }
    }
}
