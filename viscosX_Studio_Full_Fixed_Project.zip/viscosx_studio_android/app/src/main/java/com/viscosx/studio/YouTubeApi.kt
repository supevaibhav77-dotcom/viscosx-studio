package com.viscosx.studio

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object YouTubeApi {
    data class ChannelStats(
        val title: String,
        val subscribers: String,
        val views: String,
        val videos: String
    )

    private fun request(
        url: String,
        token: String,
        method: String = "GET",
        body: ByteArray? = null,
        contentType: String = "application/json"
    ): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20000
            readTimeout = 60000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", contentType)
                setFixedLengthStreamingMode(body.size)
            }
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val message = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException("YouTube API error $code: ${message ?: text.take(300)}")
            }
            return text
        } finally {
            conn.disconnect()
        }
    }

    fun loadChannel(token: String, done: (Result<ChannelStats>) -> Unit) {
        Thread {
            try {
                val raw = request(
                    "https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true",
                    token
                )
                val item = JSONObject(raw).getJSONArray("items").optJSONObject(0)
                    ?: throw IllegalStateException("No YouTube channel was found for this Google account.")
                val stats = item.getJSONObject("statistics")
                val channelStats = ChannelStats(
                    item.getJSONObject("snippet").optString("title", "Your channel"),
                    if (stats.optBoolean("hiddenSubscriberCount")) "Hidden" else stats.optString("subscriberCount", "0"),
                    stats.optString("viewCount", "0"),
                    stats.optString("videoCount", "0")
                )
                Handler(Looper.getMainLooper()).post { done(Result.success(channelStats)) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { done(Result.failure(e)) }
            }
        }.start()
    }

    fun uploadVideo(
        context: Context,
        token: String,
        uri: Uri,
        title: String,
        description: String,
        privacy: String,
        done: (Result<String>) -> Unit
    ) {
        Thread {
            try {
                val resolver = context.contentResolver
                val mime = resolver.getType(uri) ?: "video/mp4"
                val size = getSize(resolver, uri)
                require(size > 0) { "Could not read the selected video file." }

                val metadata = JSONObject().apply {
                    put("snippet", JSONObject().apply {
                        put("title", title)
                        put("description", description)
                        put("categoryId", "20")
                        put("tags", org.json.JSONArray(listOf("PhantomBladeZero", "Shorts", "viscosX")))
                    })
                    put("status", JSONObject().apply {
                        put("privacyStatus", privacy)
                        put("selfDeclaredMadeForKids", false)
                    })
                }.toString().toByteArray(Charsets.UTF_8)

                val init = (URL("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
                    .openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 20000
                    readTimeout = 30000
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("X-Upload-Content-Type", mime)
                    setRequestProperty("X-Upload-Content-Length", size.toString())
                }
                init.outputStream.use { it.write(metadata) }
                val initCode = init.responseCode
                val uploadUrl = init.getHeaderField("Location")
                val initError = if (initCode !in 200..299) init.errorStream?.bufferedReader()?.use { it.readText() } else null
                init.disconnect()
                if (initCode !in 200..299 || uploadUrl.isNullOrBlank()) {
                    throw IllegalStateException("Could not start upload ($initCode): ${initError ?: "No upload URL returned"}")
                }

                val put = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PUT"
                    doOutput = true
                    connectTimeout = 30000
                    readTimeout = 180000
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", mime)
                    setFixedLengthStreamingMode(size)
                }
                val input = resolver.openInputStream(uri)
                    ?: throw IllegalStateException("Could not open the selected video file.")
                input.use { videoInput ->
                    put.outputStream.use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val bytesRead = videoInput.read(buffer)
                            if (bytesRead == -1) break
                            output.write(buffer, 0, bytesRead)
                        }
                    }
                }
                val code = put.responseCode
                val response = (if (code in 200..299) put.inputStream else put.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                put.disconnect()
                if (code !in 200..299) throw IllegalStateException("Upload failed ($code): ${response.take(400)}")
                val videoId = JSONObject(response).optString("id")
                Handler(Looper.getMainLooper()).post { done(Result.success("Upload complete. Video ID: $videoId")) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { done(Result.failure(e)) }
            }
        }.start()
    }

    private fun getSize(resolver: ContentResolver, uri: Uri): Long {
        resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0)
        }
        return -1L
    }
}
